(function ($) {
  'use strict';

  $('.form-validation').validate();

})(jQuery);
